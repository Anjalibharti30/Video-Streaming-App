# Video-Streaming-App-master
Developed a video streaming application like YouTube, where users can upload their videos for general users to see, they can like, comment and share the videos along with custom Admin Panel.
